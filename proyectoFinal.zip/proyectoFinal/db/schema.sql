CREATE TABLE IF NOT EXISTS `maquina` (
  `id_maquina` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `activado` DATETIME NOT NULL,
  `desactivado` DATETIME NOT NULL,
  `diferencia` TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS `alarmaTemperatura` (
  `id_alarma` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `limite` INTEGER NOT NULL,
  `temperatura_max` INTEGER NOT NULL,
  `alarma_maquina` INTEGER NOT NULL,
  FOREIGN KEY(alarma_maquina) REFERENCES maquina(id_maquina));

CREATE TABLE IF NOT EXISTS `temperatura` (
  `lim_temp` INTEGER NOT NULL);