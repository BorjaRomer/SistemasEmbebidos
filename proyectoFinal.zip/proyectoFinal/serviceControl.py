import time
from time import sleep
import sqlite3
import dht_config
from datetime import datetime
import RPi.GPIO as GPIO

DATABASE = 'db/database.db'
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#IN, OUT
led = 18
th = 17
inter = 15
sensor = dht_config.DHT(th)
GPIO.setup(inter, GPIO.IN)
GPIO.setup(led, GPIO.OUT)
activado = datetime.now()
desactivado = datetime.now()
limite = 27

#Insertamos una parada en la base de datos
def insertarParada(activado, desactivado, diferencia):
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
    cur.execute("INSERT INTO 'maquina' (activado, desactivado, diferencia) VALUES (?,?,?)", (activado, desactivado, diferencia))
    conn.commit()
    conn.close()

#Insertamos un registro de alarma en la base de datos
def insertarAlarma(temperatura_max, id_maquina):
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
    cur.execute("INSERT INTO 'alarmaTemperatura' (limite, temperatura_max, alarma_maquina) VALUES (?,?,?)", (limite, temperatura_max, id_maquina))
    conn.commit()
    conn.close()

#Devuleve el id de parada que se ha generado con la activación de la alarma, de esta forma, los relacionamos como en la base de datos
def get_id_maquina():
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
    cur.execute("SELECT MAX(id_maquina) FROM maquina")
    valor = cur.fetchall()
    idmaq = valor[0][0]
    conn.commit()
    conn.close()
    return idmaq

#Devuelve el límite de temperatura para comprobar si algún usuario ha modificado el valor desde la aplicación web
def get_lim_temp():
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
    cur.execute("SELECT lim_temp FROM temperatura")
    valor = cur.fetchall()
    tempg = valor[0][0]
    conn.commit()
    conn.close()
    return tempg

#Código encargado de recoger información de los sensores e introducirlos en la base de datos
while True:
    t = get_lim_temp()
    if t != limite:
        limite = t
    hum, temp = sensor.read()
    estadoInter = GPIO.input(inter)
    if estadoInter == 1:
        activado = datetime.now().replace(microsecond = 0)
        while True:
            estadoInter = GPIO.input(inter)
            if estadoInter == 0:
                desactivado = datetime.now().replace(microsecond = 0)
                diferencia = desactivado - activado
                insertarParada(activado, desactivado, str(diferencia))
                break
    if temp > limite:
        GPIO.output(led, GPIO.HIGH)
        activado = datetime.now().replace(microsecond = 0)
        temperatura_max = 0
        while True:
            hum, temp = sensor.read()
            if temp > temperatura_max:
                temperatura_max = temp
            if temp < limite:
                desactivado = datetime.now().replace(microsecond = 0)
                diferencia = desactivado - activado
                insertarParada(activado, desactivado, str(diferencia))
                time.sleep(2)
                id_maquina = get_id_maquina()
                insertarAlarma(temperatura_max, id_maquina)
                GPIO.output(led, GPIO.LOW)
                break
    
        