from flask import Flask, g, render_template, request, redirect
import RPi.GPIO as GPIO
import sqlite3
import dht_config

app = Flask(__name__)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

DATABASE = 'db/database.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

#IN,OUT
th = 17
led = 18
led2 = 23
inter = 15
sensor = dht_config.DHT(th)
GPIO.setup(led, GPIO.OUT)
GPIO.setup(led2, GPIO.OUT)
GPIO.setup(inter, GPIO.IN)


@app.route('/')
def home():
    return "Sistema MES"

#Template para visualizar los datos
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

#Estados de todos los sensores conectados a la máquina en el momento
@app.route('/estados')
def estados():
    estadoLed = GPIO.input(led)
    estadoLed2 = GPIO.input(led2)
    estadoInter = GPIO.input(inter)
    hum, temp = sensor.read()
    if estadoLed == 1:
        ledE = "Activada"
        interS = "Parada por temperatura"
    else:
        ledE = "Desconectada"
    if estadoInter == 1:
        interS = "Parada por operario"
    elif estadoLed == 0:
        interS = "En funcionamiento"
    if estadoLed2 == 1:
        ledE2 = "En marcha"
    else:
        ledE2 = "Apagado"
    templateData = {
        'estadoLed' : ledE,
        'estadoInter' : interS,
        'estadoTemp' : temp,
        'estadoLed2' : ledE2
    }
    return render_template('estados.html', **templateData)

#Template para mostrar variables modificables para interactuar con el encargado
@app.route('/entradas', methods=['GET', 'POST'])
def entradas():
    conn = get_db()
    estadoLed2 = GPIO.input(led2)
    temperatura = get_temperatura(conn)
    templateData = {
        'estadoLed2' :  estadoLed2,
        'temperatura' : temperatura
    }
    if request.method == 'POST':
        temperatura = request.form['temp']
        conn = get_db()
        update_temperatura(conn, temperatura)
        return redirect(request.url)

    return render_template('entradas.html', **templateData)

#Modifica las salidas de los sensores 
@app.route('/entradas/<device>/<action>')
def acciones(device, action):
    if device == 'led':
        if action == 'on':
            GPIO.output(led2, GPIO.HIGH)
        else:
            GPIO.output(led2, GPIO.LOW)

    conn = get_db()
    estadoLed2 = GPIO.input(led2)
    temperatura = get_temperatura(conn)

    templateData = {
        'estadoLed2' :  estadoLed2,
        'temperatura' : temperatura
    }
        
    return render_template('entradas.html', **templateData)

#Devuelve una lista de paradas de la máquina con filtros
@app.route('/dashboard/paradas/<filtro>')
def paradasMaquina(filtro):
    conn = get_db()
    if filtro == "fe":
        fil = "activado"
    else:
        fil = "diferencia DESC"
    valores = get_paradas_maquina(conn, fil)
    templateData ={
        'filtros' : True
    }
    return render_template('dashboard_parada.html', data=valores, **templateData)

#Devuelve una lista de alarmas que se han generado por excesiva temperatura
@app.route('/dashboard/alarmas')
def alarmasMaquina():
    conn = get_db()
    valores = get_alarmas(conn)
    return render_template('dashboard_alarma.html', data=valores)

#Devuelve una parada de la maquina relacionada con la alarma seleccionada
@app.route('/dashboard/parada/<id_maquina>')
def paradaMaquina(id_maquina):
    conn = get_db()
    valores = get_parada(conn, id_maquina)
    return render_template('dashboard_parada.html', data=valores)

#Hace una petición a base de datos sobre las paradas de la máquina
def get_paradas_maquina(conn, fil):
    cur = conn.cursor()
    cur.execute("SELECT * FROM maquina order by " + fil)   
    valores = cur.fetchall()
    return valores

#Hacer una petición a base de datos sobre las alarmas por temperatura
def get_alarmas(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM alarmaTemperatura")
    valores = cur.fetchall()
    return valores

#Hacer una petición a base de datos sobre un parada en concreto
def get_parada(conn, val):
    cur = conn.cursor()
    cur.execute("SELECT * FROM maquina WHERE id_maquina=" + val)   
    valores = cur.fetchall()
    return valores

#Modificar el límite de temperatura para que salte la alarma
def update_temperatura(conn, temperatura):
    cur = conn.cursor()
    cur.execute("UPDATE temperatura SET lim_temp=" + temperatura)
    conn.commit()
    conn.close()

#Devulve el límite de temperatura asignado en el momento
def get_temperatura(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM temperatura")   
    valores = cur.fetchall()
    return valores

#Para acceder desde fuera de la red
if __name__ == "__main__":
   app.run(debug=True, host='0.0.0.0')   

